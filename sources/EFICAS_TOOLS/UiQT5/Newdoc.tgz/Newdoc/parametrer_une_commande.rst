.. _form-label:

===============
Edit a command
===============

Each command has to be setted up. Eficas generates a data entry form.
This form varies dynamicaly, depending on the context : rules and already existing values.

This widget appears by selecting (clicking) on a command (first level in the tree view).

.. image:: images/DoubleFleche.png
   :align: right

You can navigate from command to command using the arrows buttons:


The command widget
--------------------

this widget is divided vertically into three separate areas : 
   - the tree view, 
   - the form widget  
   - the optionnal keywords. 

When needed, views provide scrollbar so that the entire information can be viewed.

A bottom widget provides a horizontal bar for presenting documentation as the status bar  is used to display error or warning messages.
    
.. image:: images/Main.png
   :align: center

|
|

Edit values
-------------

Eficas use many different widgets in order to help you to choose values :

- Line editors for simple values
- Entry lists widgets 
- Popup lists
- Group boxes of button

see :ref:`features-label` to know more about each widget.
 
|

.. image:: images/Erreur.png
   :align: left
Eficas does not let you enter invalid values. It checks the type and the cardinality of the value. 
It ensures that the value is in the value domain or proposes  a set of discrete values.
Data entered is checked against a set of rules. Errors are displayed in red to draw attention.

|
|
|
|
|
|


Form construction is dynamic
----------------------------

The form is updated according to values.  it asks for the field depending on what's selected.

In the exemple below: 

- if value of 'Initial_Conditions' is 'Zero Elevation', no additional data is needed
- if value of 'Initial_Conditions' is 'TPXO satellite altimetry', you have to fill 'Ascii_Database_For_Tide'

.. image:: images/Zero.png
   :align: left


|
|
|
|
|

.. image:: images/TPXO.png
   :align: left

|
|
|
|
|
|
|
|
|
|
Displaying optionnal keyword
------------------------------

When you create a new command, the widget opens with the optionnal keywords of this command. 

.. image:: images/OptionnelCommande.png
   :align: center

|
When entering in a "group keyword", the optionnal keywords list is updated to show optionnal keyword for this specific "group keyword".

.. image:: images/OptionnelCommande1.png
   :align: center


By clicking on command label ("INITIALIZATION") or on keyword label ("Input_files"), the corresponding optionnal keywords list is displayed.

Sometimes, when a user enters a value for a keyword, optionnal keywords  are dependents on this value. Optionnal keywords lists is updated.
This is the case for conditionnal keywords
 
.. image:: images/OptionnelParametersAdao.png
   :align: center

|

.. image:: images/OptionnelParametersAdao1.png
   :align: center

|
adding/deleting an optionnal keyword
------------------------------------

.. image:: images/DblClickOnOptional.png
   :align: left
Optionnals keywords (if any) are in the right part of the "command window". Just double-click on the checkbox to add the keyword.
The input data form is redisplayed and the list of possible optionnals keywords will be updated (for example, if two keywords cannot be simultaneously present).


.. image:: images/poubelle.png
   :align: right
To delete a keyword (or a command), just click the garbage icon : 

|
|
|
|
|
Tooltips 
--------

**Use tooltips to have information.**


.. image:: images/ToolTipOnLabel.png
   :align: left
- Tooltips on **labels** display **information about the keyword**. Double-click on the label to display this information in the comment area, at the bottom of the window. This is useful for long text. *(You also can double-click on the keyword in the tree dataset.)*

|
|
|
|
.. image:: images/ToolTipOnLineEdit.png
   :align: left
- Tooltips on **lineEdit** (one-line text editor) display **suggestion** for the input value. Suggestion are not very frequent. They are not default values, because you have to enter it explicitely.


|
|
|
|
.. image:: images/ToolTipOnRed.png
   :align: left
- Tooltips on **Red point**  display **information about the validity** for the keyword or for the group of keywords.
By double-clicking on the "red point" a window displaying the same information appears. It should be usefull if text
is too long to be read at one sitting.


|
|
|
|
.. image:: images/ToolTipOnButton.png
   :align: left
- Tooltips on **Commands Button**  explain what the icon / Button represents, and which action is activated by clicking.

|
  
