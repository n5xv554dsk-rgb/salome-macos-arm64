Add a command
=============

In Eficas, many common commands can be invoked via menus, toolbar buttons as well as keyboard shortcuts.
As in many GUI, a menu widget can be either a pull-down menu or a standalone context menu. Pull-down menus are shown by the menu bar when the user clicks on the respective item or presses the specified shortcut key. Context menus are usually invoked by some special keyboard key or by right-clicking.
Eficas allows you to write (and reread) an unvalid file. At any time, you can save your works. 

build a new data set.
---------------------
Launch eficas and choose "Nouveau/New" 

.. image:: images/Nouveau.png
   :align: center


Choose a Code
---------------

Eficas will ask you to choose the code you want to work with, each time you click on "Nouveau/New" or "Ouvrir/Open" in the "Fichier/File" Menu, unless you have started Eficas for a specific code.

.. image:: images/ChoixCode.png
   :align: center

and a version of the Code
----------------------------

if many catalogs (ie many versions ) are available, eficas will ask you to select one.

.. image:: images/ChoixCata.png
   :align: center

Enter commands
-------------------------

Eficas main widget provided two distinct views: The left size always contains the JDC explorer as a tree view. The right widget contains all commands the user is allowed to select.

.. image:: images/ChoixCommande.png
   :align: center

To have command's documentation (if available), simple-click on the command. 

.. image:: images/Documentation1.png
   :align: center

To add the command click twice. The new command is added after the current command (highlighted in the tree view). In case of impossibility, a message is displayed.   

.. image:: images/Ordre.png
   :align: center



The user  also can choose the way the commands are sorted, either by alphabetical order, either by fonctionnalities.
Last type of sorting commands is called 'by modelisation' that is to say logical order to prepare data for the code.  

.. image:: images/Groupes.png
   :align: center


The content filtering system is very simple : only commands containing the expression are shown.

.. image:: images/FiltreCommande.png
   :align: center


Il faut faire fonctionner cela
The user can use "Filtre", which is a filter widget to find a command position. The PushButton "suivant" shows the next matching command. 
Eficas main widget provided two distinct views: The left size always contains the JDC explorer as a tree view. The right widget contains all commandsi the user is allowed to use. It shows which commands are available and which :ref:`rules-label`  have to be followed. Commands are append after this selected in the JDC tree.

