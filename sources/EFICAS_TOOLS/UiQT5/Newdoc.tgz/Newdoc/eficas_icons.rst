.. _icons-label:

=======================
Using icons in Eficas 
=======================

Icons are used because they are presumed to save time, but all actions can be accessed from menus 
Eficas use a small set of icons. Hopefully, users are familiar with. However, all icons are labelled.


Managing Files  
--------------
Alternatively you can go to the "File" menu (in menuBar) or use shortcut 


.. image:: images/icons/gerer_fichiers.png     
   :align: center


Managing Keywords  
------------------
Alternatively you can go to the "Edit" menu (in menuBar) or use shortcut 


.. image:: images/icons/gerer_MCs.png     
   :align: center


Shortcuts
---------

Eficas keybord shortcuts require the user to press a sequence of keys.
These sequences contain 'Ctrl' for common shortcuts as "Ctrl+C", Alt for accessing actio
n of menu, and 'Shift' for specific actions


   

