.. _navigation-label :

=====================
Eficas Main Window
=====================
.. image:: images/Main.png

========================
Navigation within Eficas
========================

Collapsed/Expand Items
-----------------------


